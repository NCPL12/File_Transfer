require("dotenv").config();
const sql = require("mssql");
const WebSocket = require("ws");
const localtunnel = require("localtunnel");

const config = {
  user: process.env.SQL_USER,
  password: process.env.SQL_PASSWORD,
  server: process.env.SQL_SERVER,
  database: process.env.SQL_DATABASE,
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
};

const wss = new WebSocket.Server({ port: 8080 });
let lastSeenId = null;

wss.on("connection", (ws) => {
  console.log("📲 Mobile connected");
  ws.send(JSON.stringify({ status: "Connected to alarm server" }));
});

async function pollAlarms() {
  try {
    await sql.connect(config);
    const result = await sql.query(`
      SELECT TOP 1 * FROM [dbo].[alarmOrion_OrionAlarmRecord]
      ORDER BY [timestamp] DESC
    `);

    const latest = result.recordset[0];
    if (!latest) return;

    if (latest.id !== lastSeenId) {
      lastSeenId = latest.id;

      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ alarm: latest }));
        }
      });

      console.log("🚨 Sent new alarm:", latest.id);
    }
  } catch (error) {
    console.error("❌ DB Polling Error:", error.message);
  }
}

setInterval(pollAlarms, 5000); // every 5 seconds

(async () => {
  const tunnel = await localtunnel({ port: 8080, subdomain: "alarmwsdemo" });
  console.log("🔗 WebSocket public URL:", tunnel.url);
})();
